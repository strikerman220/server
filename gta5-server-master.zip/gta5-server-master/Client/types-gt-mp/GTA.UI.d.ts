﻿declare namespace GTA.UI {

	enum Font {
		ChaletLondon = 0,
		HouseScript = 1,
		Monospace = 2,
		ChaletComprimeCologne = 4,
		Pricedown = 7
	}

}
