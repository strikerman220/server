﻿declare namespace NativeUI.UIMenu {

	enum MenuControls {
		Up = 0,
		Down = 1,
		Left = 2,
		Right = 3,
		Select = 4,
		Back = 5
	}

}
