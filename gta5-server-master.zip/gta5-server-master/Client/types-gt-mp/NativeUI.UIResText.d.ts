﻿declare namespace NativeUI.UIResText {

	enum Alignment {
		Left = 0,
		Centered = 1,
		Right = 2
	}

}
