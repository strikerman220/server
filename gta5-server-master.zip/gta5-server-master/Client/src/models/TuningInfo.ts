export class TuningInfo {
    public Name: string
    public Slot: number
    public Price: number
    public Values: number[]
}