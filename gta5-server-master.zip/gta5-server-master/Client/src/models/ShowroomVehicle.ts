export class ShowroomVehicle {
    public Id: number
    public Hash: number
    public Price: number
    public MaxFuel: number
    public Type: number
}