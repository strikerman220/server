export class InventoryItem {
    public Id: number
    public Name: string
    public Type: number
    public Count: number
    public CountInHouse: number
    public Hash?: number
}