export class AfkVehicle {
    public Id: number
    public Position: Vector3
}