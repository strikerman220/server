export class ClothesModel {
    public Variation: number
    public Slot: number
    public Torso?: number
    public Undershirt?: number
    public IsClothes: boolean
    public Texture: number
    public Textures: number[]
    public Price: number
}