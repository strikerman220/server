export class WeaponGood {
    public Name: string
    public Model: number
    public Price: number
}