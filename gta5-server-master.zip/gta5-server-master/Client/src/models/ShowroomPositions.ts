export class ShowroomPositions {
    public PreviewPosition: Vector3
    public PreviewRotation: Vector3
    public CameraPosition: Vector3
    public CameraRotation: Vector3
}