export class PoliceAlert {
    public Id: number
    public Position: Vector3
    public Name: string
}