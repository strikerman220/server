export class DeliveryContract {
    public Name: string
    public TargetPosition: Vector3
    public Reward: number
}