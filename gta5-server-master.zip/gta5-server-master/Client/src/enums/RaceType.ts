export enum RaceType {
    Cars = 1,
    Moto,
    Rally,
    Mountain
} 