﻿namespace gta_mp_server.Managers.Phone.Interfaces {
    internal interface IPhoneManager {
        /// <summary>
        /// Проинициализировать голосовой сервер
        /// </summary>
        void Initialize();
    }
}