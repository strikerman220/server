﻿namespace gta_mp_server.Managers.Work.Trucker.Interfaces {
    internal interface ITruckersManager {
        /// <summary>
        /// Инициализация менеджера работы дальнобойщиком
        /// </summary>
        void Initialize();
    }
}