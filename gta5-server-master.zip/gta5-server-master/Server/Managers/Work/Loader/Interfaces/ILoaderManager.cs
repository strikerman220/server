﻿namespace gta_mp_server.Managers.Work.Loader.Interfaces {
    internal interface ILoaderManager {
        /// <summary>
        /// Инициализировать свойства
        /// </summary>
        void Initialize();
    }
}