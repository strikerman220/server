﻿namespace gta_mp_server.Managers.Work.Wrecker.Interfaces {
    internal interface IWreckerManager {
        /// <summary>
        /// Проинициализировать работу эвакуаторщиком
        /// </summary>
        void Initialize();
    }
}