﻿namespace gta_mp_server.Managers.Work.Fisherman.Interfaces {
    internal interface IFishermanManager {
        /// <summary>
        /// Проинициализировать работу
        /// </summary>
        void Initialize();
    }
}