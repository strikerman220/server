﻿namespace gta_mp_server.Managers.Work.Farmer.Interfaces {
    internal interface ITractorDriverManager {
        /// <summary>
        /// Инизиализировать работу
        /// </summary>
        void Initialize();
    }
}