﻿namespace gta_mp_server.Managers.Work.Farmer.Interfaces {
    public interface IFarmerManager {
        /// <summary>
        /// Инициализация работы
        /// </summary>
        void Initialize();
    }
}