﻿namespace gta_mp_server.Managers.Work.Pilot.Interfaces {
    internal interface IPilotManager {
        /// <summary>
        /// Проинициализировать работу пилотов
        /// </summary>
        void Initialize();
    }
}