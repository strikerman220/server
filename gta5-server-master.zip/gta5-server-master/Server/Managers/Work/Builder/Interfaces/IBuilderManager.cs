﻿namespace gta_mp_server.Managers.Work.Builder.Interfaces {
    internal interface IBuilderManager {
        /// <summary>
        /// Проинициализировать работу строителе
        /// </summary>
        void Initialize();
    }
}