﻿namespace gta_mp_server.Managers.House.Interfaces {
    internal interface IStorageManager {
        /// <summary>
        /// Проинициализировать обработчик гардероба
        /// </summary>
        void Initialize();
    }
}