﻿namespace gta_mp_server.Managers.Player.Interfaces {
    public interface IPlayerManager {
        /// <summary>
        /// Обновить состояния игроков
        /// </summary>
        void UpdatePlayers();
    }
}