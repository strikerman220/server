﻿namespace gta_mp_server.Managers.NPC.Interfaces {
    internal interface INpc {
        /// <summary>
        /// Создать нпс
        /// </summary>
        void Initialize();
    }
}