﻿namespace gta_mp_server.Managers.Interface.Interfaces {
    internal interface IInterfaceManager {
        /// <summary>
        /// Инициализировать интерфейсные обработчики
        /// </summary>
        void Initialize();
    }
}