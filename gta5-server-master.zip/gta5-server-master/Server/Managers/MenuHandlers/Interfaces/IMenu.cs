﻿namespace gta_mp_server.Managers.MenuHandlers.Interfaces {
    internal interface IMenu {
        /// <summary>
        /// Инициализировать обработчик меню
        /// </summary>
        void Initialize();
    }
}