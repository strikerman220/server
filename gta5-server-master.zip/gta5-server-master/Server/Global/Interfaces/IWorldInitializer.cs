﻿namespace gta_mp_server.Global.Interfaces {
    public interface IWorldInitializer {
        /// <summary>
        /// Инициализовать игровой мир
        /// </summary>
        void Initialize();
    }
}