﻿namespace gta_mp_server.Global.Interfaces {
    public interface IDatabaseSynchronizer {
        /// <summary>
        /// Запустить синхронайзер
        /// </summary>
        void Start();
    }
}