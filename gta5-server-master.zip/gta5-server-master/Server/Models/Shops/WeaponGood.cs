﻿namespace gta_mp_server.Models.Shops {
    /// <summary>
    /// Модель продаваемого оружия
    /// </summary>
    internal class WeaponGood {
        public string Name { get; set; }
        public int Model { get; set; }
        public int Price { get; set; }
    }
}