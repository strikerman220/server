﻿namespace gta_mp_server.Models.Work {
    /// <summary>
    /// Модель вознаграждения за работу
    /// </summary>
    internal class WorkReward {
        public int Salary { get; set; }
        public int Exp { get; set; }
        public int WorkExp { get; set; }
    }
}