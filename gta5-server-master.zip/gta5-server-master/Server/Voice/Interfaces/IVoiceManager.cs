﻿namespace gta_mp_server.Voice.Interfaces {
    internal interface IVoiceManager {}
}