﻿namespace gta_mp_server.Enums {
    /// <summary>
    /// Тип автосалона
    /// </summary>
    internal enum ShowroomType {
        Cheap = 1,
        Expensive,
        Clan
    }
}