﻿namespace gta_mp_server.Enums {
  public enum BlipColor {
    Red = 1,
    LightGreen = 2,
    LightBlue = 3,
    White = 4,
    Yellow = 5,
    WineRed = 6,
    Purple = 7,
    Pink = 8,
    Complexion = 9,
    LightBrown = 10,
    LightGreen2 = 11,
    GulfStream = 12,
    Snuff = 13,
    Mamba = 14,
    Orange = 47
  }
}
