﻿using GrandTheftMultiplayer.Shared;

namespace gta_mp_server.Enums.Vehicles {
    public enum SuperCar {
        //T20 = VehicleHash.T20,
        //Xa21 = VehicleHash.XA21,
        //Flying = 1483171323,
        //Shotaro = VehicleHash.Shotaro
        A = -376434238,
        B = -1134706562,
        C = 1031562256,
        E = -2120700196,
        F = 1046206681,
        Cheb = -988501280,
        Elli = -1267543371,
    }
}