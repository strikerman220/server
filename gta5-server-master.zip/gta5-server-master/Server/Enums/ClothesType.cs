﻿namespace gta_mp_server.Enums {
    /// <summary>
    /// Тип одежды
    /// </summary>
    public enum ClothesType {
        Accessory = 1,
        Clothes = 2
    }
}