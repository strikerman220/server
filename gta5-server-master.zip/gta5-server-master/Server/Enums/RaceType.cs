﻿namespace gta_mp_server.Enums {
    /// <summary>
    /// Тип гонки
    /// </summary>
    internal enum RaceType {
        Cars = 1,
        Moto,
        Rally,
        Mountain
    }
}